#!/bin/bash

hostname -I
