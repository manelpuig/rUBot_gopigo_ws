#!/bin/bash

# Set this machine has ROS master.
export ROS_MASTER_URI=http://localhost:11311/
