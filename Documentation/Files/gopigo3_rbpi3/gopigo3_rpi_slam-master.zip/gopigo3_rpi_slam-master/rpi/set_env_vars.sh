#!/bin/bash

# Replace the IP (XXX) with the real master's IP.
export ROS_MASTER_URI=http://192.168.4.18:11311/
