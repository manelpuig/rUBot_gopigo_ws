
"use strict";

let MotorStatusLR = require('./MotorStatusLR.js');
let MotorStatus = require('./MotorStatus.js');

module.exports = {
  MotorStatusLR: MotorStatusLR,
  MotorStatus: MotorStatus,
};
