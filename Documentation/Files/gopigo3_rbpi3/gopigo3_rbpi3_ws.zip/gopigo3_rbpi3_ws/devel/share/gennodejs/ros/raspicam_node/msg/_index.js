
"use strict";

let MotionVectors = require('./MotionVectors.js');

module.exports = {
  MotionVectors: MotionVectors,
};
