
"use strict";

let SPI = require('./SPI.js')

module.exports = {
  SPI: SPI,
};
