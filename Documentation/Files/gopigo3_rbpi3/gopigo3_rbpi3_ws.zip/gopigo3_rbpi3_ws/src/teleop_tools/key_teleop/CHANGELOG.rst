^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package key_teleop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2020-06-04)
------------------
* Value should be int
* Bump CMake version to avoid CMP0048
* Fix install of python scripts for Noetic
* Python3 compatibility for noetic (`#52 <https://github.com/ros-teleop/teleop_tools/issues/52>`_)
* Contributors: Bence Magyar, Tim Clephas

0.3.1 (2020-02-10)
------------------

0.3.0 (2019-01-03)
------------------

0.2.6 (2018-04-06)
------------------

0.2.5 (2017-04-21)
------------------

0.2.4 (2016-11-30)
------------------

0.2.3 (2016-07-18)
------------------

0.2.2 (2016-03-24)
------------------

0.2.1 (2016-01-29)
------------------

0.2.0 (2015-08-03)
------------------
* Update package.xmls
* Contributors: Bence Magyar

0.1.2 (2015-02-15)
------------------

0.1.1 (2014-11-17)
------------------
* Change maintainer
* Remove rosbuild legacy
* Merge key_teleop into teleop_tools
* Contributors: Bence Magyar, Paul Mathieu
