void mmal_vc_client(void) {
}
